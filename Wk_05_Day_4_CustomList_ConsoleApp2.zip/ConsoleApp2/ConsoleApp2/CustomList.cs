﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    public class CustomList<T>
    {
        private T[] items = new T[1];
        public int Count { get; }

        public void Add(T item)
        {

        }
    }
}
